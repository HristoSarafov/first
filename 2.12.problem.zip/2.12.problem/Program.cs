﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2._12.problem
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("PLease insert: ");
            Console.Write("N integer: ");
            int n = Math.Abs(int.Parse(Console.ReadLine()));
            Console.Write("M integer: ");
            int m = Math.Abs(int.Parse(Console.ReadLine()));
            Console.Write("Maximum boundary of the sum: ");
            int maxBoundary = int.Parse(Console.ReadLine());
            int sum=0;
            int count = 0;
            for(int k = n;k>=1;n--) 
            {
                for (int i = 1; i <= m; i++)
                {
                    if (sum >= maxBoundary)
                    {

                        break;
                    }
                    else
                    {
                        count++;
                        sum += 3 * (n * i);
                    }
                }
                    
                    if(sum >= maxBoundary)
                    {

                        break;
                    }              
            }
            if (sum >= maxBoundary)
            {
                Console.WriteLine("{0} Combinations \r\n Sum: {1} >= {2}", count, sum, maxBoundary);
            }
            else
            {


                Console.WriteLine("{0} Combinations \r\n Sum: {1}", count, sum);
            }
            Console.ReadLine();

        }
    }
}
